﻿namespace SuperAdventure
{
    partial class WorldMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pic_0_0 = new System.Windows.Forms.PictureBox();
            this.pic_0_1 = new System.Windows.Forms.PictureBox();
            this.pic_0_2 = new System.Windows.Forms.PictureBox();
            this.pic_0_3 = new System.Windows.Forms.PictureBox();
            this.pic_0_4 = new System.Windows.Forms.PictureBox();
            this.pic_1_0 = new System.Windows.Forms.PictureBox();
            this.pic_1_1 = new System.Windows.Forms.PictureBox();
            this.pic_1_2 = new System.Windows.Forms.PictureBox();
            this.pic_1_3 = new System.Windows.Forms.PictureBox();
            this.pic_1_4 = new System.Windows.Forms.PictureBox();
            this.pic_2_0 = new System.Windows.Forms.PictureBox();
            this.pic_2_1 = new System.Windows.Forms.PictureBox();
            this.pic_2_2 = new System.Windows.Forms.PictureBox();
            this.pic_2_3 = new System.Windows.Forms.PictureBox();
            this.pic_2_4 = new System.Windows.Forms.PictureBox();
            this.pic_3_0 = new System.Windows.Forms.PictureBox();
            this.pic_3_1 = new System.Windows.Forms.PictureBox();
            this.pic_3_2 = new System.Windows.Forms.PictureBox();
            this.pic_3_3 = new System.Windows.Forms.PictureBox();
            this.pic_3_4 = new System.Windows.Forms.PictureBox();
            this.pic_0_5 = new System.Windows.Forms.PictureBox();
            this.pic_1_5 = new System.Windows.Forms.PictureBox();
            this.pic_2_5 = new System.Windows.Forms.PictureBox();
            this.pic_3_5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_5)).BeginInit();
            this.SuspendLayout();
            // 
            // pic_0_0
            // 
            this.pic_0_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_0.Location = new System.Drawing.Point(0, 1);
            this.pic_0_0.Name = "pic_0_0";
            this.pic_0_0.Size = new System.Drawing.Size(75, 75);
            this.pic_0_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_0.TabIndex = 0;
            this.pic_0_0.TabStop = false;
            // 
            // pic_0_1
            // 
            this.pic_0_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_1.Location = new System.Drawing.Point(81, 1);
            this.pic_0_1.Name = "pic_0_1";
            this.pic_0_1.Size = new System.Drawing.Size(75, 75);
            this.pic_0_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_1.TabIndex = 1;
            this.pic_0_1.TabStop = false;
            // 
            // pic_0_2
            // 
            this.pic_0_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_2.Location = new System.Drawing.Point(162, 1);
            this.pic_0_2.Name = "pic_0_2";
            this.pic_0_2.Size = new System.Drawing.Size(75, 75);
            this.pic_0_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_2.TabIndex = 2;
            this.pic_0_2.TabStop = false;
            // 
            // pic_0_3
            // 
            this.pic_0_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_3.Location = new System.Drawing.Point(243, 1);
            this.pic_0_3.Name = "pic_0_3";
            this.pic_0_3.Size = new System.Drawing.Size(75, 75);
            this.pic_0_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_3.TabIndex = 3;
            this.pic_0_3.TabStop = false;
            // 
            // pic_0_4
            // 
            this.pic_0_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_4.Location = new System.Drawing.Point(324, 1);
            this.pic_0_4.Name = "pic_0_4";
            this.pic_0_4.Size = new System.Drawing.Size(75, 75);
            this.pic_0_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_4.TabIndex = 4;
            this.pic_0_4.TabStop = false;
            // 
            // pic_1_0
            // 
            this.pic_1_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_0.Location = new System.Drawing.Point(0, 82);
            this.pic_1_0.Name = "pic_1_0";
            this.pic_1_0.Size = new System.Drawing.Size(75, 75);
            this.pic_1_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_0.TabIndex = 5;
            this.pic_1_0.TabStop = false;
            // 
            // pic_1_1
            // 
            this.pic_1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_1.Location = new System.Drawing.Point(81, 82);
            this.pic_1_1.Name = "pic_1_1";
            this.pic_1_1.Size = new System.Drawing.Size(75, 75);
            this.pic_1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_1.TabIndex = 6;
            this.pic_1_1.TabStop = false;
            // 
            // pic_1_2
            // 
            this.pic_1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_2.Location = new System.Drawing.Point(162, 82);
            this.pic_1_2.Name = "pic_1_2";
            this.pic_1_2.Size = new System.Drawing.Size(75, 75);
            this.pic_1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_2.TabIndex = 7;
            this.pic_1_2.TabStop = false;
            // 
            // pic_1_3
            // 
            this.pic_1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_3.Location = new System.Drawing.Point(243, 82);
            this.pic_1_3.Name = "pic_1_3";
            this.pic_1_3.Size = new System.Drawing.Size(75, 75);
            this.pic_1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_3.TabIndex = 8;
            this.pic_1_3.TabStop = false;
            // 
            // pic_1_4
            // 
            this.pic_1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_4.Location = new System.Drawing.Point(324, 82);
            this.pic_1_4.Name = "pic_1_4";
            this.pic_1_4.Size = new System.Drawing.Size(75, 75);
            this.pic_1_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_4.TabIndex = 9;
            this.pic_1_4.TabStop = false;
            // 
            // pic_2_0
            // 
            this.pic_2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_0.Location = new System.Drawing.Point(0, 163);
            this.pic_2_0.Name = "pic_2_0";
            this.pic_2_0.Size = new System.Drawing.Size(75, 75);
            this.pic_2_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_0.TabIndex = 10;
            this.pic_2_0.TabStop = false;
            // 
            // pic_2_1
            // 
            this.pic_2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_1.Location = new System.Drawing.Point(81, 163);
            this.pic_2_1.Name = "pic_2_1";
            this.pic_2_1.Size = new System.Drawing.Size(75, 75);
            this.pic_2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_1.TabIndex = 11;
            this.pic_2_1.TabStop = false;
            // 
            // pic_2_2
            // 
            this.pic_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_2.Location = new System.Drawing.Point(162, 163);
            this.pic_2_2.Name = "pic_2_2";
            this.pic_2_2.Size = new System.Drawing.Size(75, 75);
            this.pic_2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_2.TabIndex = 12;
            this.pic_2_2.TabStop = false;
            // 
            // pic_2_3
            // 
            this.pic_2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_3.Location = new System.Drawing.Point(243, 163);
            this.pic_2_3.Name = "pic_2_3";
            this.pic_2_3.Size = new System.Drawing.Size(75, 75);
            this.pic_2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_3.TabIndex = 13;
            this.pic_2_3.TabStop = false;
            // 
            // pic_2_4
            // 
            this.pic_2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_4.Location = new System.Drawing.Point(324, 163);
            this.pic_2_4.Name = "pic_2_4";
            this.pic_2_4.Size = new System.Drawing.Size(75, 75);
            this.pic_2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_4.TabIndex = 14;
            this.pic_2_4.TabStop = false;
            // 
            // pic_3_0
            // 
            this.pic_3_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_0.Location = new System.Drawing.Point(0, 244);
            this.pic_3_0.Name = "pic_3_0";
            this.pic_3_0.Size = new System.Drawing.Size(75, 75);
            this.pic_3_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_0.TabIndex = 15;
            this.pic_3_0.TabStop = false;
            // 
            // pic_3_1
            // 
            this.pic_3_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_1.Location = new System.Drawing.Point(81, 244);
            this.pic_3_1.Name = "pic_3_1";
            this.pic_3_1.Size = new System.Drawing.Size(75, 75);
            this.pic_3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_1.TabIndex = 16;
            this.pic_3_1.TabStop = false;
            // 
            // pic_3_2
            // 
            this.pic_3_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_2.Location = new System.Drawing.Point(162, 244);
            this.pic_3_2.Name = "pic_3_2";
            this.pic_3_2.Size = new System.Drawing.Size(75, 75);
            this.pic_3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_2.TabIndex = 17;
            this.pic_3_2.TabStop = false;
            // 
            // pic_3_3
            // 
            this.pic_3_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_3.Location = new System.Drawing.Point(243, 244);
            this.pic_3_3.Name = "pic_3_3";
            this.pic_3_3.Size = new System.Drawing.Size(75, 75);
            this.pic_3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_3.TabIndex = 18;
            this.pic_3_3.TabStop = false;
            // 
            // pic_3_4
            // 
            this.pic_3_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_4.Location = new System.Drawing.Point(324, 244);
            this.pic_3_4.Name = "pic_3_4";
            this.pic_3_4.Size = new System.Drawing.Size(75, 75);
            this.pic_3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_4.TabIndex = 19;
            this.pic_3_4.TabStop = false;
            // 
            // pic_0_5
            // 
            this.pic_0_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_0_5.Location = new System.Drawing.Point(405, 1);
            this.pic_0_5.Name = "pic_0_5";
            this.pic_0_5.Size = new System.Drawing.Size(75, 75);
            this.pic_0_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_0_5.TabIndex = 20;
            this.pic_0_5.TabStop = false;
            // 
            // pic_1_5
            // 
            this.pic_1_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_1_5.Location = new System.Drawing.Point(405, 82);
            this.pic_1_5.Name = "pic_1_5";
            this.pic_1_5.Size = new System.Drawing.Size(75, 75);
            this.pic_1_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_1_5.TabIndex = 21;
            this.pic_1_5.TabStop = false;
            // 
            // pic_2_5
            // 
            this.pic_2_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_2_5.Location = new System.Drawing.Point(405, 163);
            this.pic_2_5.Name = "pic_2_5";
            this.pic_2_5.Size = new System.Drawing.Size(75, 75);
            this.pic_2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_2_5.TabIndex = 22;
            this.pic_2_5.TabStop = false;
            // 
            // pic_3_5
            // 
            this.pic_3_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_3_5.Location = new System.Drawing.Point(405, 244);
            this.pic_3_5.Name = "pic_3_5";
            this.pic_3_5.Size = new System.Drawing.Size(75, 75);
            this.pic_3_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_3_5.TabIndex = 23;
            this.pic_3_5.TabStop = false;
            // 
            // WorldMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 322);
            this.Controls.Add(this.pic_3_5);
            this.Controls.Add(this.pic_2_5);
            this.Controls.Add(this.pic_1_5);
            this.Controls.Add(this.pic_0_5);
            this.Controls.Add(this.pic_3_4);
            this.Controls.Add(this.pic_3_3);
            this.Controls.Add(this.pic_3_2);
            this.Controls.Add(this.pic_3_1);
            this.Controls.Add(this.pic_3_0);
            this.Controls.Add(this.pic_2_4);
            this.Controls.Add(this.pic_2_3);
            this.Controls.Add(this.pic_2_2);
            this.Controls.Add(this.pic_2_1);
            this.Controls.Add(this.pic_2_0);
            this.Controls.Add(this.pic_1_4);
            this.Controls.Add(this.pic_1_3);
            this.Controls.Add(this.pic_1_2);
            this.Controls.Add(this.pic_1_1);
            this.Controls.Add(this.pic_1_0);
            this.Controls.Add(this.pic_0_4);
            this.Controls.Add(this.pic_0_3);
            this.Controls.Add(this.pic_0_2);
            this.Controls.Add(this.pic_0_1);
            this.Controls.Add(this.pic_0_0);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WorldMap";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "World Map";
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_0_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_1_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_3_5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_0_0;
        private System.Windows.Forms.PictureBox pic_0_1;
        private System.Windows.Forms.PictureBox pic_0_2;
        private System.Windows.Forms.PictureBox pic_0_3;
        private System.Windows.Forms.PictureBox pic_0_4;
        private System.Windows.Forms.PictureBox pic_1_0;
        private System.Windows.Forms.PictureBox pic_1_1;
        private System.Windows.Forms.PictureBox pic_1_2;
        private System.Windows.Forms.PictureBox pic_1_3;
        private System.Windows.Forms.PictureBox pic_1_4;
        private System.Windows.Forms.PictureBox pic_2_0;
        private System.Windows.Forms.PictureBox pic_2_1;
        private System.Windows.Forms.PictureBox pic_2_2;
        private System.Windows.Forms.PictureBox pic_2_3;
        private System.Windows.Forms.PictureBox pic_2_4;
        private System.Windows.Forms.PictureBox pic_3_0;
        private System.Windows.Forms.PictureBox pic_3_1;
        private System.Windows.Forms.PictureBox pic_3_2;
        private System.Windows.Forms.PictureBox pic_3_3;
        private System.Windows.Forms.PictureBox pic_3_4;
        private System.Windows.Forms.PictureBox pic_0_5;
        private System.Windows.Forms.PictureBox pic_1_5;
        private System.Windows.Forms.PictureBox pic_2_5;
        private System.Windows.Forms.PictureBox pic_3_5;
    }
}
